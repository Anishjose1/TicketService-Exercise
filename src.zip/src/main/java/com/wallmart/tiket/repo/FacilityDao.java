package com.wallmart.tiket.repo;

import org.springframework.data.repository.CrudRepository;

import com.wallmart.tiket.domain.Facility;

public interface FacilityDao extends CrudRepository<Facility,Long>{

		
}
